// var x = 44;
// x += 3;
// document.write("<br>+= Operator: ",x);
// x -= 2;
// document.write("<br>-= Operator: ",x);
// x *= 2;
// document.write("<br>*= Operator: ",x);
// x /= 2;
// document.write("<br>/= Operator: ",x);
// x %= 2;
// document.write("<br>%= Operator: ",x);
// x **= 2;
// document.write("<br>**= Operator: ",x);


let x = 100;
x = x&5;
document.write("<br>& Operator: ",x)
x = x|5;
document.write("<br>| Operator: ",x)
x = x^5;
document.write("<br> ^ Operator: ",x)

// x = (5>7)&&(7>5)
// document.write("<br> && Operator: ",x)





